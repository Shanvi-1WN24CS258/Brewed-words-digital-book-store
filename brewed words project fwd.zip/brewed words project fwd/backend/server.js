// backend/server.js - UPDATED VERSION
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

// Import routes
const authRoutes = require('./routes/auth');
const commentRoutes = require('./routes/comments');
const userRoutes = require('./routes/user');

const app = express();

// Middleware
app.use(cors({
      origin: function(origin, callback) {
        // Allow requests with no origin (like mobile apps or curl requests)
        if (!origin) return callback(null, true);
        
        // Allow all localhost origins
        if (origin.match(/^https?:\/\/localhost(:\d+)?$/) || 
            origin.match(/^https?:\/\/127\.0\.0\.1(:\d+)?$/)) {
            return callback(null, true);
        }
        
        // Allow file:// protocol (for testing)
        if (origin === 'null' || origin.startsWith('file://')) {
            return callback(null, true);
        }
        
        callback(new Error('Not allowed by CORS'));
    },
    credentials: true
}));
app.use(express.json());

// Database Connection
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    console.log('✅ Connected to MongoDB Atlas');
    console.log('📊 Database:', mongoose.connection.name);
})
.catch((err) => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/user', userRoutes);

// Test Route
app.get('/', (req, res) => {
    res.json({ 
        message: 'Library API is running with MongoDB!',
        database: 'MongoDB Atlas',
        status: 'Connected'
    });
});

// Health Check
app.get('/api/health', async (req, res) => {
    try {
        const dbStatus = mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected';
        
        res.json({
            status: 'OK',
            timestamp: new Date().toISOString(),
            database: dbStatus,
            uptime: process.uptime()
        });
    } catch (error) {
        res.status(500).json({ 
            status: 'ERROR', 
            message: error.message 
        });
    }
});

// Error Handling Middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ 
        success: false, 
        message: 'Something went wrong!',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`🔐 API Endpoints:`);
    console.log(`   POST http://localhost:${PORT}/api/auth/register`);
    console.log(`   POST http://localhost:${PORT}/api/auth/login`);
    console.log(`   PUT  http://localhost:${PORT}/api/auth/update-email`);
    console.log(`   PUT  http://localhost:${PORT}/api/auth/update-password`);
    console.log(`   GET  http://localhost:${PORT}/api/health`);
});
// Log all available endpoints
console.log(`   POST http://localhost:${PORT}/api/comments`);
console.log(`   GET  http://localhost:${PORT}/api/comments/book/:bookId`);
console.log(`   GET  http://localhost:${PORT}/api/user/library`);
console.log(`   POST http://localhost:${PORT}/api/user/library`);
console.log(`   GET  http://localhost:${PORT}/api/user/favorites`);
console.log(`   POST http://localhost:${PORT}/api/user/favorites`);
console.log(`   GET  http://localhost:${PORT}/api/user/me`);