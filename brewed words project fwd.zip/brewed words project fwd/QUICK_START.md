# ⚡ Quick Start Guide

## 🚀 Get Running in 5 Minutes

### 1. Set Up MongoDB
- Sign up at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) (free)
- Create a cluster → Create database user → Whitelist IP → Get connection string

### 2. Configure Backend
```bash
cd backend
# Copy .env.example to .env
Copy-Item .env.example .env  # Windows
# OR
cp .env.example .env  # Mac/Linux

# Edit .env and add your MongoDB connection string
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/library-db
# JWT_SECRET=your-random-secret-key
```

### 3. Install & Start Backend
```bash
cd backend
npm install
npm start
```

You should see:
```
✅ Connected to MongoDB Atlas
🚀 Server running on http://localhost:5000
```

### 4. Test Connection
Open browser: `http://localhost:5000/api/health`

### 5. Open Frontend
- Open any HTML file in the `frontend` folder (e.g., `book-details.html`, `explore.html`)
- ✅ `config.js` is already included in all HTML files
- The frontend should now connect to the backend!

---

## 📝 Key Files

- **Backend Config**: `backend/.env` (create from `.env.example`)
- **Frontend Config**: `frontend/config.js` (already configured)
- **API Base URL**: `http://localhost:5000` (default)

---

## 🔍 Verify Everything Works

1. **Backend Health**: `http://localhost:5000/api/health` ✅
2. **Register User**: Use frontend registration form ✅
3. **Login**: Use frontend login form ✅
4. **Add Comment**: Try adding a comment on a book ✅

---

## 🆘 Common Issues

### PowerShell Execution Policy Error
If you see: `"running scripts is disabled on this system"`

**Quick Fix (Run in PowerShell as Admin):**
```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Or use Command Prompt instead:**
- Press `Windows + R`, type `cmd`, press Enter
- Navigate to `backend` folder and run `npm install`

See `FIX_POWERSHELL.md` for detailed solutions.

### Other Issues
- **"Cannot connect to MongoDB"** → Check `.env` file has correct connection string
- **"Port 5000 in use"** → Change PORT in `.env` to 5001
- **"CORS error"** → Make sure backend is running on port 5000

For detailed setup, see `SETUP_GUIDE.md`

