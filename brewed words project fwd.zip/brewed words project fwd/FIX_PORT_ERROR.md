# 🔧 Fix "Port 5000 Already in Use" Error

## Problem
```
Error: listen EADDRINUSE: address already in use :::5000
```

This means port 5000 is already being used by another process.

## ✅ Solution Options

### Option 1: Kill the Process Using Port 5000 (Recommended)

**In Command Prompt or PowerShell, run:**

```cmd
netstat -ano | findstr :5000
```

This will show you the process ID (PID) using port 5000. Look for something like:
```
TCP    0.0.0.0:5000    0.0.0.0:0    LISTENING    12345
```

Then kill that process (replace 12345 with your actual PID):
```cmd
taskkill /PID 12345 /F
```

**Or use this one-liner:**
```cmd
for /f "tokens=5" %a in ('netstat -ano ^| findstr :5000') do taskkill /F /PID %a
```

After killing the process, try `npm start` again.

### Option 2: Change the Port (Alternative)

If you want to use a different port:

1. **Edit `backend/.env` file:**
   ```
   PORT=5001
   ```

2. **Update `frontend/config.js`:**
   ```javascript
   const API_BASE_URL = 'http://localhost:5001';
   ```

3. **Restart the server:**
   ```cmd
   npm start
   ```

### Option 3: Find What's Using Port 5000

**To see what process is using port 5000:**

```cmd
netstat -ano | findstr :5000
```

Then check the process name:
```cmd
tasklist | findstr <PID>
```

---

## 🎯 Quick Fix (Copy & Paste)

**Run this in Command Prompt:**
```cmd
for /f "tokens=5" %a in ('netstat -ano ^| findstr :5000') do taskkill /F /PID %a
```

Then:
```cmd
npm start
```

This will kill any process using port 5000 and let you start your server.

