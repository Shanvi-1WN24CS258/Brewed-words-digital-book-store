# 🔧 Fix PowerShell Execution Policy Error

## Problem
You're seeing this error:
```
npm : File C:\Program Files\nodejs\npm.ps1 cannot be loaded because running scripts is disabled on this system.
```

## ✅ Solution Options

### Option 1: Change Execution Policy (Recommended - One Time Fix)

**Run PowerShell as Administrator:**
1. Press `Windows Key + X`
2. Select "Windows PowerShell (Admin)" or "Terminal (Admin)"
3. Run this command:
   ```powershell
   Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
4. Type `Y` when prompted
5. Close and reopen your terminal
6. Now `npm install` and `npm start` will work!

### Option 2: Bypass for Current Session (Quick Fix)

**In your current PowerShell window, run:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
```

Then try `npm install` again. This only works for the current session.

### Option 3: Use Command Prompt Instead (No Admin Needed)

**Use CMD instead of PowerShell:**
1. Press `Windows Key + R`
2. Type `cmd` and press Enter
3. Navigate to your project:
   ```cmd
   cd "C:\Users\shanv\OneDrive\Documents\brewed words project fwd\backend"
   ```
4. Run:
   ```cmd
   npm install
   npm start
   ```

### Option 4: Use Git Bash (If You Have Git)

If you have Git installed, you can use Git Bash which doesn't have this restriction:
1. Right-click in your project folder
2. Select "Git Bash Here"
3. Run:
   ```bash
   cd backend
   npm install
   npm start
   ```

---

## 🎯 Recommended: Option 1

**Option 1 is best** because it fixes the issue permanently for your user account. You only need to do it once.

After fixing, your commands will work:
```powershell
cd backend
npm install
npm start
```

