# 🚀 Complete Setup Guide - Backend, Frontend & Database Connection

This guide will help you connect your backend, frontend, and MongoDB database.

## 📋 Prerequisites

- Node.js (v14 or higher) installed
- MongoDB Atlas account (free tier works) OR local MongoDB installation
- A code editor (VS Code recommended)

---

## 🔧 Step 1: Set Up MongoDB Database

### Option A: MongoDB Atlas (Cloud - Recommended)

1. **Create a MongoDB Atlas Account**
   - Go to [https://www.mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
   - Sign up for a free account

2. **Create a Cluster**
   - Click "Build a Database"
   - Choose the FREE tier (M0)
   - Select a cloud provider and region
   - Click "Create"

3. **Create Database User**
   - Go to "Database Access" in the left sidebar
   - Click "Add New Database User"
   - Choose "Password" authentication
   - Create a username and password (save these!)
   - Set privileges to "Atlas Admin" or "Read and write to any database"
   - Click "Add User"

4. **Whitelist Your IP Address**
   - Go to "Network Access" in the left sidebar
   - Click "Add IP Address"
   - Click "Allow Access from Anywhere" (for development) or add your IP
   - Click "Confirm"

5. **Get Your Connection String**
   - Go to "Database" → Click "Connect"
   - Choose "Connect your application"
   - Copy the connection string (looks like: `mongodb+srv://username:password@cluster.mongodb.net/`)
   - Replace `<password>` with your actual password
   - Replace `<dbname>` with `library-db` (or your preferred database name)

### Option B: Local MongoDB

1. **Install MongoDB**
   - Download from [https://www.mongodb.com/try/download/community](https://www.mongodb.com/try/download/community)
   - Install and start MongoDB service
   - Connection string: `mongodb://localhost:27017/library-db`

---

## 🔐 Step 2: Configure Backend Environment

1. **Navigate to Backend Folder**
   ```bash
   cd backend
   ```

2. **Create `.env` File**
   - Copy `.env.example` to `.env`:
     ```bash
     # On Windows (PowerShell)
     Copy-Item .env.example .env
     
     # On Mac/Linux
     cp .env.example .env
     ```

3. **Edit `.env` File**
   - Open `.env` in your editor
   - Update `MONGODB_URI` with your MongoDB connection string:
     ```
     MONGODB_URI=mongodb+srv://yourusername:yourpassword@cluster.mongodb.net/library-db?retryWrites=true&w=majority
     ```
   - Update `JWT_SECRET` with a secure random string (you can generate one online or use a password generator)
     ```
     JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
     ```
   - Keep `PORT=5000` (or change if needed)

---

## 📦 Step 3: Install Backend Dependencies

1. **Navigate to Backend Folder** (if not already there)
   ```bash
   cd backend
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

   This will install:
   - Express (web framework)
   - Mongoose (MongoDB ODM)
   - JWT (authentication)
   - bcryptjs (password hashing)
   - CORS (cross-origin requests)
   - dotenv (environment variables)

---

## 🚀 Step 4: Start the Backend Server

1. **Start the Server**
   ```bash
   npm start
   ```
   
   Or for development with auto-reload:
   ```bash
   npm run dev
   ```

2. **Verify Backend is Running**
   - You should see:
     ```
     ✅ Connected to MongoDB Atlas
     📊 Database: library-db
     🚀 Server running on http://localhost:5000
     ```
   - Open browser: `http://localhost:5000`
   - You should see: `{"message":"Library API is running with MongoDB!","database":"MongoDB Atlas","status":"Connected"}`
   - Test health endpoint: `http://localhost:5000/api/health`

---

## 🌐 Step 5: Configure Frontend

1. **Check Frontend Configuration**
   - Open `frontend/config.js`
   - Verify `API_BASE_URL` is set to:
     ```javascript
     const API_BASE_URL = 'http://localhost:5000';
     ```
   - This should already be correct, but verify it matches your backend port

2. **Include config.js in HTML Files**
   - Make sure all your HTML files include `config.js` before other scripts:
     ```html
     <script src="config.js"></script>
     <script src="shared.js"></script>
     <!-- other scripts -->
     ```

---

## 🧪 Step 6: Test the Connection

### Test 1: Backend Health Check
```bash
# Using curl (if available)
curl http://localhost:5000/api/health

# Or open in browser
http://localhost:5000/api/health
```

### Test 2: Register a User
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"test123"}'
```

### Test 3: Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123"}'
```

### Test 4: Frontend Connection
1. Open your frontend HTML file (e.g., `index2.html`)
2. Open browser DevTools (F12)
3. Check Console for any errors
4. Try to register/login from the frontend
5. Check Network tab to see API calls

---

## 📁 Project Structure

```
brewed-words-project-fwd/
├── backend/
│   ├── models/
│   │   ├── user.js          # User model
│   │   ├── book.js          # Book model
│   │   └── comment.js       # Comment model
│   ├── routes/
│   │   ├── auth.js          # Authentication routes
│   │   ├── comments.js      # Comment routes
│   │   └── user.js          # User library/favorites routes
│   ├── middleware/
│   │   └── auth.js          # JWT authentication middleware
│   ├── server.js            # Main server file
│   ├── package.json         # Dependencies
│   └── .env                 # Environment variables (create this)
│
└── frontend/
    ├── config.js            # API configuration
    ├── shared.js            # Shared functions
    ├── *.html               # HTML pages
    └── *.js                 # Page-specific scripts
```

---

## 🔗 API Endpoints Reference

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Comments
- `GET /api/comments/book/:bookId` - Get comments for a book
- `POST /api/comments` - Add a comment (requires auth)

### User Library & Favorites
- `GET /api/user/library` - Get user's library (requires auth)
- `POST /api/user/library` - Add book to library (requires auth)
- `DELETE /api/user/library/:bookId` - Remove from library (requires auth)
- `GET /api/user/favorites` - Get user's favorites (requires auth)
- `POST /api/user/favorites` - Add to favorites (requires auth)
- `DELETE /api/user/favorites/:bookId` - Remove from favorites (requires auth)
- `GET /api/user/me` - Get current user profile (requires auth)

---

## 🐛 Troubleshooting

### Backend won't start
- **Error: "Cannot find module"**
  - Run `npm install` in the backend folder
  
- **Error: "MongoDB connection error"**
  - Check your `.env` file has correct `MONGODB_URI`
  - Verify MongoDB Atlas IP whitelist includes your IP
  - Check username/password in connection string

- **Error: "Port already in use"**
  - Change `PORT` in `.env` to a different number (e.g., 5001)
  - Or stop the process using port 5000

### Frontend can't connect to backend
- **CORS Error**
  - Backend CORS is configured to allow localhost
  - Make sure backend is running on port 5000
  - Check `config.js` has correct `API_BASE_URL`

- **401 Unauthorized**
  - Make sure user is logged in
  - Check token is stored in `localStorage`
  - Verify token is sent in Authorization header

### Database Issues
- **"User already exists"**
  - This is normal if you try to register the same email twice
  - Use a different email or login instead

- **Empty collections**
  - This is normal for a new database
  - Data will be created as users register and add books

---

## 🎯 Next Steps

1. **Test User Registration/Login**
   - Register a new user from the frontend
   - Login and verify token is stored

2. **Test Comments**
   - Add comments to books
   - View comments on book details page

3. **Test Library & Favorites**
   - Add books to library
   - Add books to favorites
   - View them in My Library and Favorites pages

4. **Populate Books Database** (Optional)
   - Create a script to add books to MongoDB
   - Or use the frontend's `shared.js` book data

---

## 📝 Important Notes

- **Never commit `.env` file to Git** - It contains sensitive information
- **Change JWT_SECRET in production** - Use a strong random string
- **Update CORS settings for production** - Only allow your frontend domain
- **Use HTTPS in production** - For secure API communication

---

## ✅ Checklist

- [ ] MongoDB Atlas account created and cluster set up
- [ ] Database user created with password
- [ ] IP address whitelisted
- [ ] Connection string copied
- [ ] `.env` file created with correct values
- [ ] Backend dependencies installed (`npm install`)
- [ ] Backend server starts without errors
- [ ] MongoDB connection successful
- [ ] Frontend `config.js` has correct API URL
- [ ] Can register/login from frontend
- [ ] API calls work from browser DevTools

---

## 🆘 Need Help?

If you encounter issues:
1. Check the console/terminal for error messages
2. Verify all environment variables are set correctly
3. Ensure MongoDB is accessible (test connection string)
4. Check that backend is running before testing frontend
5. Verify CORS settings allow your frontend origin

---

**Happy Coding! 🎉**

