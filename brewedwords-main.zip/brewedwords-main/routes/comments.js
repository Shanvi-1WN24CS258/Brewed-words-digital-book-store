const express = require('express');
const router = express.Router();
const Comment = require('../models/comment');

// GET - Get comments for a book
router.get('/book/:bookId', async (req, res) => {
    try {
        const bookId = parseInt(req.params.bookId);
        const comments = await Comment.find({ bookId: bookId })
            .sort({ createdAt: -1 }); // Newest first
        
        res.json({
            success: true,
            comments: comments.map(comment => ({
                id: comment._id,
                bookId: comment.bookId,
                userName: comment.userName,
                text: comment.text,
                date: comment.createdAt.toLocaleDateString()
            }))
        });
    } catch (error) {
        console.error('Get comments error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// POST - Add a comment
router.post('/', async (req, res) => {
    try {
        const { bookId, userId, userName, text } = req.body;
        
        // Create new comment
        const comment = new Comment({
            bookId: parseInt(bookId),
            userId,
            userName,
            text
        });
        
        await comment.save();
        
        res.status(201).json({
            success: true,
            message: 'Comment added successfully',
            comment: {
                id: comment._id,
                bookId: comment.bookId,
                userName: comment.userName,
                text: comment.text,
                date: comment.createdAt.toLocaleDateString()
            }
        });
    } catch (error) {
        console.error('Add comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

module.exports = router;